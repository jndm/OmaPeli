package com.me.mygdxgame.screens;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;
import com.me.mygdxgame.OmaPeli;
import com.me.mygdxgame.elements.Alusta;
import com.me.mygdxgame.elements.Ammus;
import com.me.mygdxgame.elements.Pelihahmo;
import com.me.mygdxgame.elements.Vihollinen;

public class GameScreen implements Screen{
	private final OmaPeli game;

	private Texture hpImage;
	private OrthographicCamera camera;

	private float painovoima;
    private ArrayList<Alusta> alustat;
    private Pelihahmo pelihahmo;
    private Array<Vihollinen> viholliset;
    private boolean kameraPaikallaanX, kameraPaikallaanY;
    private long lastPressProcessed;
    private long lastEnemyTime;
	private DecimalFormat df;
	private float stateTime;
	private TextureRegion nykyinenHahmoFrame;

	public GameScreen(final OmaPeli game) {
		this.game = game;

		hpImage = new Texture(Gdx.files.internal("hp.png"));
		hpImage.setFilter(TextureFilter.Linear, TextureFilter.Linear);
		
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 800, 480);
		
		alustaMaailma();
		df = new DecimalFormat("#.#");
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0.4f, 1);
		Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
		
		camera.position.set(new Vector3(pelihahmo.getX(), pelihahmo.getY(),0));
		camera.update();
		
		stateTime += Gdx.graphics.getDeltaTime(); //lasketaan animaatioita varten aikaa
		
		//Virallinen SpriteBatch, jolla piirret��n debugtekstit ja pelihahmoanimaatio
		game.batch.setProjectionMatrix(camera.combined);
		game.batch.begin();
		game.font.draw(game.batch, "vY: "+df.format(pelihahmo.getLiikeY())+"", pelihahmo.getX(), pelihahmo.getY());
		game.font.draw(game.batch, "vX: "+df.format(pelihahmo.getLiikeX()), pelihahmo.getX(), pelihahmo.getY()-16);
		game.font.draw(game.batch, "v: "+pelihahmo.vasemmassaSeinassa(), pelihahmo.getX(), pelihahmo.getY()-32);
		game.font.draw(game.batch, "o: "+pelihahmo.oikeassaSeinassa(), pelihahmo.getX(), pelihahmo.getY()-48);
		game.font.draw(game.batch, "lattia: "+pelihahmo.isGrounded(), pelihahmo.getX(), pelihahmo.getY()-64);
		game.batch.draw(pelihahmo.getNykyinenFrame(), pelihahmo.getX(), pelihahmo.getY());
		game.batch.end();
		
		
		//Hudia varten luotu peliluokassa oma batch, jota ei aseteta seuraamaan cameran matriisia(?) jolloin sen x on aina 0-800 ja y 0-480
		game.hudBatch.begin();
        for(int i = 0; i < pelihahmo.getHp(); ++i) game.hudBatch.draw(hpImage, 5+i*20, 480-hpImage.getHeight()-5);
        game.hudBatch.end();
		
        //ShapeRenderer jolla piirret��n alustat ja viholliset
		game.sr.setProjectionMatrix(camera.combined);	
		game.sr.begin(ShapeType.Line);
		game.sr.rect(pelihahmo.getX(), pelihahmo.getY(), pelihahmo.getHalkaisija(), pelihahmo.getHalkaisija());
		game.sr.circle(pelihahmo.getX(), pelihahmo.getY(), 2);
		Iterator<Alusta> alustaIte = alustat.iterator();
        while(alustaIte.hasNext()) {
        	Alusta alusta = (Alusta)alustaIte.next();
        	game.sr.rect(alusta.x, alusta.y, alusta.width, alusta.height);
        }
		Iterator<Ammus> ammusIte = pelihahmo.getAmmukset().iterator();
        while(ammusIte.hasNext()) {
        	Ammus ammus = (Ammus)ammusIte.next();
        	game.sr.circle(ammus.getX(), ammus.getY(), ammus.getHalkaisija()/2.0f);
        }
        game.sr.end();

		game.sr.begin(ShapeType.Filled);

		Iterator<Vihollinen> vihuIte = viholliset.iterator();
		while(vihuIte.hasNext()){
        	Vihollinen vihu = vihuIte.next();
			game.sr.rect(vihu.x, vihu.y, vihu.width, vihu.height, new Color(Color.BLUE), new Color(Color.RED), new Color(Color.BLUE), new Color(Color.RED));
		}
        game.sr.end();
        
		if(Gdx.input.isKeyPressed(Keys.SPACE)){
        	pelihahmo.hyppaa();
        }
        if(Gdx.input.isKeyPressed(Keys.Z)){
            if(TimeUtils.millis() - lastPressProcessed > 100) {
                pelihahmo.ammu();
                lastPressProcessed = TimeUtils.millis();
            }
        }
        if(Gdx.input.isKeyPressed(Keys.RIGHT) || Gdx.input.isKeyPressed(Keys.LEFT)){
	        if(Gdx.input.isKeyPressed(Keys.RIGHT)) {
	            pelihahmo.liikuX(1, stateTime);
	        }
	        if (Gdx.input.isKeyPressed(Keys.LEFT)) {
	            pelihahmo.liikuX(-1, stateTime);
	        }
        }else{
        	pelihahmo.liikuX(0, stateTime);
        }
        if(Gdx.input.isKeyPressed(Keys.SHIFT_LEFT)){
        	pelihahmo.sprinttaa(true);
        }
        else pelihahmo.sprinttaa(false);

		paivitaMaailma();
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void show() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
		
		
	}
	
	private void paivitaMaailma(){
        ArrayList<Ammus> ammukset = pelihahmo.getAmmukset();
        kameraPaikallaanX = true;
        kameraPaikallaanY = true;
        
        if((pelihahmo.getY()<200 && pelihahmo.getLiikeY()<0) || (pelihahmo.getY()>280 && pelihahmo.getLiikeY()>0))  //Jos l�hestyt��n ruudun reunaa, liikutetaan muita hahmon sijaan.
            kameraPaikallaanY=false;
        if((pelihahmo.getX()<300 && pelihahmo.getLiikeX()<0) || (pelihahmo.getX()>500 && pelihahmo.getLiikeX()>0))  //Jos l�hestyt��n ruudun reunaa, liikutetaan muita hahmon sijaan.
            kameraPaikallaanX=false;

        Iterator<Vihollinen> iteVihu = viholliset.iterator();
        while(iteVihu.hasNext()){
            Vihollinen vihu = iteVihu.next();
            vihu.liiku(painovoima, pelihahmo.getLiikeY(), pelihahmo.getLiikeX(), kameraPaikallaanX, kameraPaikallaanY);   //Vihollisten liikutus
        }
        /*
        for (Alusta alusta : alustat) {
            alusta.liiku(pelihahmo.getLiikeY(), -pelihahmo.getLiikeX(), kameraPaikallaanX, kameraPaikallaanY);  //Alustojen liikutus
        }
        */
        Iterator<Ammus> ammusIte = ammukset.iterator();
        while(ammusIte.hasNext()){
            ammusIte.next().liiku(pelihahmo.getLiikeY(), pelihahmo.getLiikeX(), kameraPaikallaanX, kameraPaikallaanY);   //Ammusten liikutus
        }
        
        pelihahmo.liiku(painovoima, kameraPaikallaanX, kameraPaikallaanY); //Pelihahmon Liikutus
        
        // asetetaan hahmo alustalle jos mahdollista
        for (Alusta alusta : alustat){
            this.pelihahmo.yritaKayttaaAlustaa(alusta);
            iteVihu = viholliset.iterator();
            while(iteVihu.hasNext())
                iteVihu.next().yritaKayttaaAlustaa(alusta);
            
            ammusIte = ammukset.iterator();
            while(ammusIte.hasNext()){
                if(ammusIte.next().tarkistaTormays(alusta)){
                	ammusIte.remove();
                }
            }
        }
        
        iteVihu = viholliset.iterator();
        while(iteVihu.hasNext()){
            Vihollinen vihu = iteVihu.next();
            
            ListIterator<Ammus> iteAmmus = ammukset.listIterator();
            while(iteAmmus.hasNext()){
                if(iteAmmus.next().tarkistaTormaysVihu(vihu)){
                    //this.pelihahmo.poistaAmmus(iterator);
                    vihu.setHp(vihu.getHp()-1);
                    if(vihu.getHp()==0){
                        iteVihu.remove();
                    }
                    iteAmmus.remove();
                }
            }
            
            if(pelihahmo.tarkistaVihuTormays(vihu)){
                iteVihu.remove();
                pelihahmo.setHp(pelihahmo.getHp()-1);
            }
        }
        
        // nopeutetaan peli� 600 kierroksen v�lein (600 kierrosta on noin 
        // 10 sekuntia)
        if (TimeUtils.millis() - lastEnemyTime > 5000)
        	spawnEnemy();
	}
	
	private void spawnEnemy(){
		Rectangle vihollinen = new Vihollinen();
		vihollinen.x = MathUtils.random(alustat.get(0).x + alustat.get(0).width, alustat.get(1).x - 16);
		vihollinen.y = MathUtils.random(alustat.get(0).y + alustat.get(0).height, alustat.get(2).y + alustat.get(2).height);
		vihollinen.width = 16;
		vihollinen.height = 16;
		viholliset.add((Vihollinen)vihollinen);
		lastEnemyTime = TimeUtils.millis();
	}
	
	private void alustaMaailma(){
		painovoima = -15f;

        alustat = new ArrayList<Alusta>();
        alustat.add(new Alusta(0, -32, 32, 640));
        alustat.add(new Alusta(1600, -20, 32, 640));
        alustat.add(new Alusta(1300, 72, 32, 600));
        alustat.add(new Alusta(-32, 0, 1632, 32));
        
        alustat.add(new Alusta(64, 512, 512, 32));
        alustat.add(new Alusta(192, 384, 512, 32));
        alustat.add(new Alusta(64, 256, 512, 32));
        alustat.add(new Alusta(192, 128, 512, 32));
        viholliset = new Array<Vihollinen>();

        pelihahmo = new Pelihahmo(50, 32, 32);
	}
}
