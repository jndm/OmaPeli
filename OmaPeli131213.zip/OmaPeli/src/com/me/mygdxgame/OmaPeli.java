package com.me.mygdxgame;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.me.mygdxgame.screens.MainMenuScreen;

public class OmaPeli extends Game {
	public SpriteBatch batch;
	public SpriteBatch hudBatch;
	public BitmapFont font;
	public ShapeRenderer sr;
	
	@Override
	public void create() {
		batch = new SpriteBatch();
		hudBatch = new SpriteBatch();
		font = new BitmapFont();
		sr = new ShapeRenderer();
		this.setScreen(new MainMenuScreen(this));
	}

	@Override
	public void dispose() {
		batch.dispose();
		sr.dispose();
		font.dispose();
	}

	@Override
	public void render() {
		super.render();
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}
}
